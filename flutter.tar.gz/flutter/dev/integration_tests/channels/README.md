# channels

Integration test of platform channels.
