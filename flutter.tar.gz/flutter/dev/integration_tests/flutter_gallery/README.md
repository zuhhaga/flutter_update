# Flutter gallery

An older copy of the Flutter gallery demo application used for integration testing.

For the current Flutter Gallery app sample, see this repo:
https://github.com/flutter/gallery

## Icon

Android launcher icons were generated using Android Asset Studio:
https://romannurik.github.io/AndroidAssetStudio/icons-launcher.html#foreground.type=image&foreground.space.trim=1&foreground.space.pad=0.1&foreColor=607d8b%2C0&crop=0&backgroundShape=square&backColor=fafafa%2C100&effects=none
