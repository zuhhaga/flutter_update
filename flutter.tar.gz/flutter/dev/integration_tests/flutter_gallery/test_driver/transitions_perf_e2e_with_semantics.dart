// Copyright 2014 The Flutter Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

import 'transitions_perf_e2e.dart' as transitions_perf;

void main() {
  transitions_perf.main(<String>['--with_semantics']);
}
