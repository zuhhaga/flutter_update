# wide_gamut_test

An integration test used for testing wide gamut color support in the engine.

## Local run

```sh
flutter create --platforms="ios" --no-overwrite .
flutter test integration_test/app_test.dart
```
