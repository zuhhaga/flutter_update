# Dartdoc Samples and Snippets

The [snippets] tool uses the files in the `skeletons` directory to inject code
blocks generated from `{@tool dartpad}`, `{@tool sample}`, and `{@tool snippet}`
sections found in doc comments into the API docs.

[snippets]: https://github.com/flutter/assets-for-api-docs/tree/master/packages/snippets
